document.getElementById("champ_cache").style.display = "none";

function afficher()
{
	document.getElementById("champ_cache").style.display = "block";
}
function cacher()
{
	document.getElementById("champ_cache").style.display = "none";
}